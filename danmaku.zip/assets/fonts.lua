return {
	FloatingNumberFont = graphics.newFont(16);
	HUDFont = graphics.newFont(35);
	TitleFont = graphics.newFont(75);
}
