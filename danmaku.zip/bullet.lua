local module = {}
module.__index = module
module.__type = "Bullet"

local hit_tag = {}
local graze_tag = {}

graze_tag[1] = function(hitted)
	if not hitted:IsAlive() then
		return false
	end

	playsound("graze")
	game.Graze = game.Graze + 1
	game:AddScore(game.Graze ^ 1.25)
	return true
end

graze_tag[2] = function()
	return false
end

hit_tag[1] = function(hitted, bullet)
	-- hitted.RemoveFlag = true
	hitted:Death()
	return hitted:IsAlive()
end

hit_tag[2] = function(hitted)
	hitted.Health = hitted.Health - 1
	
	playsound(hitted.Health / hitted.MaxHealth >= 0.25 and "hit" or "hit2")
	-- print("health:", hitted.Health)
	-- game:AddScore(10)
	game.Score = game.Score + 8
	return hitted.Health > 0 
end

local function bullet_collide(_, entity, type, self)
	if type == "Bullet" or not entity.HitTagNumber then
		return
	end

	if entity.HitTagNumber ~= self.HitTagNumber then
		return -- performance
	end

	local bullet_hitbox = self.Hitbox
	local hitbox = entity.Hitbox or entity
	
	if not self.Grazed and entity.Hitbox then
		if collides(bullet_hitbox, entity) then
			self.Grazed = graze_tag[entity.HitTagNumber](entity)
		end
	end

	if collides(bullet_hitbox, hitbox) then
		local remove_it = hit_tag[self.HitTagNumber](entity, self)

		if remove_it ~= nil then
			self.RemoveFlag = true
		end
	end
end

function module:GetCenter()
	return self.X + self.Size * 0.5, self.Y + self.Size * 0.5
end

function module:UpdateHitbox()
	self.Hitbox:Update(self:GetCenter())	
end

function module:Update(dt)
	if self.Behavior then
		self.Behavior(self, dt)
	end

	self.X = self.X + ((self.XVel * self.Speed) * dt)
	self.Y = self.Y + ((self.YVel * self.Speed) * dt)
	self:UpdateHitbox()

	if self.Fencing then
		if self.X + self.Size <= 0 or self.X >= boundaries.w or self.Y + self.Size <= 0 or self.Y >= boundaries.h then
			self.RemoveFlag = true
		end
	end

	if self.CanCollide then
		game.every_entity(bullet_collide, self)
	end
end

-- local WHITE = {1.0, 1.0, 1.0, 1.0}

local draw_types = {}

draw_types[1] = function(self, dx, dy)
	graphics.setColor(self.Color)
	graphics.circle("fill", dx, dy, self.Size)
	graphics.setColor(1, 1, 1, self.Color[4] or 1)
	graphics.circle("fill", dx, dy, self.Size * 0.85)
end

draw_types[2] = function(self, dx, dy)
	graphics.setColor(self.Color)
	graphics.circle("fill", dx, dy, self.Size)
end

function module:Draw()
	-- print(self.DrawType)
	draw_types[self.DrawType](self, self.X + self.Size * 0.5, self.Y + self.Size * 0.5) 
	-- self.Hitbox:Draw()
end

function module:SetDirection(ang)
	ang = ang or 0
	self.XVel = math.cos(ang)
	self.YVel = math.sin(ang)
end

function module:GetDirection()
	return math.atan2(self.YVel, self.XVel)
end

function module.new(x, y, size, speed, xvel, yvel, color)
	local self = setmetatable({
		X = x or 0;
		Y = y or 0;
		Size = size or 10;
		Speed = speed or 50;
		XVel = xvel or 0;
		YVel = yvel or 0;
		Color = color or {1, 0, 0, 1};
		Fencing = true;
		CanCollide = true;
		HitTagNumber = 1;
		DrawType = 1;
		-- RenderPriority = 0;
	}, module)

	self.Hitbox = Hitbox.new(nil, nil, self.Size * 0.4, self.Size * 0.4)
	self:UpdateHitbox()

	self.X = self.X - self.Size * 0.5
	self.Y = self.Y - self.Size * 0.5 

	return self
end

return module
